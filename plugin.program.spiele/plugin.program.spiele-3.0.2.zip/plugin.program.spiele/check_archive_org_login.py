import xbmc, xbmcgui, xbmcvfs
from resources.lib.utils import loc_str, get_mem_cache, set_mem_cache, clear_mem_cache
from resources.lib.main import spiele_addon
from resources.lib.download import spiele_download

spiele_addon = spiele_addon()
if not get_mem_cache('spiele_script_started'):
	set_mem_cache('spiele_script_started','true')
	xbmc.log(msg='spiele:  Check archive.org login script started', level=xbmc.LOGDEBUG)
	spiele_download = spiele_download(settings=spiele_addon.settings,directory=spiele_addon.directory,game_list=None,game=None)
	spiele_download.downloader.login()
	if spiele_download.downloader.logged_in:
		current_dialog = xbmcgui.Dialog()
		ok_ret = current_dialog.ok(loc_str(30202),loc_str(30584))
		del current_dialog
		xbmc.log(msg='spiele:  Login check was successful',level=xbmc.LOGINFO)
	else:
		current_dialog = xbmcgui.Dialog()
		ok_ret = current_dialog.ok(loc_str(30203),loc_str(30585))
		del current_dialog
		xbmc.log(msg='spiele:  Login check failed',level=xbmc.LOGINFO)
	clear_mem_cache('spiele_script_started')
	xbmc.log(msg='spiele:  Check archive.org login script completed', level=xbmc.LOGDEBUG)
else:
	xbmc.log(msg='spiele:  Script already running', level=xbmc.LOGDEBUG)
del spiele_addon, spiele_download, loc_str, get_mem_cache, set_mem_cache, clear_mem_cache