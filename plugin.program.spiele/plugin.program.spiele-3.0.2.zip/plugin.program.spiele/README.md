<meta name=”robots” content=”noindex, nofollow”>

The Spiele (spiele - /eye/gull/) will launch games from the internet using [Kodi](http://kodi.tv)

spiele is *FREE*, as in beer. As in no money. As in gratis.


![spiele](https://github.com/TheDagli/PlayStation-4/tree/PS4/plugin.program.spiele/blob/main/fanart.jpg)


Installation
-------------

Do *NOT* use a third party installer, build, TVA Link, fusion installer, or other non-official means to install spiele.  Doing so is akin to clubbing baby seals.

Install spiele in one of these ways:

- Download the repository zipfile from [here](https://github.com/TheDagli/PlayStation-4/raw/master/repository.Dagli/repository.Dagli-1.0.0.zip) to install the addon and get automatic updates.

or

- Download the latest version zipfile from [here](https://github.com/TheDagli/PlayStation-4/tree/master/plugin.program.spiele) to install by zipfile.

**NOTE**
The addon in the repository is for Kodi v19 now.
Users of Kodi v18 or earlier have to manually install v2.X of the addon from [here](https://github.com/TheDagli/PlayStation-4/tree/master/plugin.program.spiele) (there is no more repository for the old version).

Licenses
-------------

spiele code is released under the [GNU GENERAL PUBLIC LICENSE Version 3](https://www.gnu.org/licenses/gpl-3.0.en.html).

Supplementary databases released with spiele, in [this folder](https://github.com/TheDagli/PlayStation-4/tree/PS4/plugin.program.spiele/tree/main/resources/data/databases), are released under the [Creative Commons Attribution-NonCommercial 4.0 International](https://creativecommons.org/licenses/by-sa/4.0/) license. This allows for *non-commercial* use as long as credit is given and that derivative works (works based on the CC licensed data) are also made available under the same license.

Media files in the skin folder are licensed under the Creative Commons Attribution-ShareAlike 4.0 Unported License.  You can find the license details [here](http://creativecommons.org/licenses/by-sa/4.0/)

Some artwork in [this folder](https://github.com/TheDagli/PlayStation-4/tree/PS4/plugin.program.spiele/tree/main/resources/skins/Default/media) is attributed to [Estuary by phil65 (Team Kodi)](https://github.com/phil65/skin.estuary)

Some audio files in [this folder](https://github.com/TheDagli/PlayStation-4/tree/PS4/plugin.program.spiele/tree/main/resources/skins/Default/media) were provided by [freesound.org](https://freesound.org/help/about/) and are licensed under the [Creative Commons license](http://creativecommons.org)

Support
-------------------

Support the internet archive by [donating](https://archive.org/donate/)!
