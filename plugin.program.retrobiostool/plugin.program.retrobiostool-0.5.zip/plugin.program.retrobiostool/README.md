<meta name=”robots” content=”noindex, nofollow”>

![](https://raw.githubusercontent.com/TheDagli/PlayStation-4/PS4/plugin.program.retrobiostool/icon.png) Retro BIOS Tool
==========================

The Retro BIOS Tool is a simple tool to copy BIOS files to the appropriate spot for Kodi game.libretro addons


Installation
-------------

Install Retro BIOS Tool in one of these ways:

- Download the repository zipfile from [here](https://github.com/TheDagli/PlayStation-4/raw/PS4/repository.dagli/repository.dagli-1.0.0.zip) to install the addon and get automatic updates.

or

- Download the latest version zipfile from [here](https://github.com/TheDagli/PlayStation-4/raw/PS4/plugin.program.retrobiostool/plugin.program.retrobiostool-0.5.zip) to install by zipfile.


Use
-------------------

Licenses
-------------

This addon is released under the [GNU GENERAL PUBLIC LICENSE Version 3](https://www.gnu.org/licenses/gpl-3.0.en.html).
