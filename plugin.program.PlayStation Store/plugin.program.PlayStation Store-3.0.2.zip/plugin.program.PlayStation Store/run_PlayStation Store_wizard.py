import xbmc, xbmcgui, xbmcvfs, xbmcaddon, xbmcplugin, re, os, shutil, json
from resources.lib.utils import loc_str, get_mem_cache, set_mem_cache, clear_mem_cache, check_and_close_notification, choose_image, get_post_dl_commands
from resources.lib.main import PlayStation Store_addon
PlayStation Store_addon_wizard = PlayStation Store_addon()
EMAIL_RE = '.+[@]\w+[.]\w+'
START_SOUND = 'special://home/addons/plugin.program.PlayStation Store/resources/skins/Default/media/wizard_start.wav'
POS_SOUND = 'special://home/addons/plugin.program.PlayStation Store/resources/skins/Default/media/coin.wav'
NEG_SOUND = 'special://home/addons/plugin.program.PlayStation Store/resources/skins/Default/media/kick.wav'
DONE_SOUND = 'special://home/addons/plugin.program.PlayStation Store/resources/skins/Default/media/wizard_done.wav'
DONE_SOUND2 = 'special://home/addons/plugin.program.PlayStation Store/resources/skins/Default/media/wizard_done2.wav'
EXT_DEFAULTS = {'32X_Dagli':['RetroArch Sega - MS/MD/CD/32X (PicoDrive)','RetroArch PicoDrive (SMS/Gen/Sega CD/32X)'],'3DO_Dagli':['RetroArch The 3DO Company - 3DO (Opera)','RetroArch The 3DO Company - 3DO (4DO)','RetroArch Opera (3DO)','RetroArch 4DO (3DO)'],'Amiga_Bestof':['RetroArch Commodore - Amiga (PUAE)','RetroArch PUAE (Amiga)','RetroArch UAE4ARM (Amiga)'],'Amiga_CD32_Dagli':['RetroArch Commodore - Amiga (PUAE)','RetroArch PUAE (Amiga)','RetroArch UAE4ARM (Amiga)'],'Amiga_Dagli':['RetroArch Commodore - Amiga (PUAE)','RetroArch PUAE (Amiga)','RetroArch UAE4ARM (Amiga)'],'Amstrad_CPC_Dagli':['RetroArch Amstrad - CPC (Caprice32)','RetroArch Amstrad - CPC (CrocoDS)','RetroArch CAP32 (Amstrad CPC)','RetroArch CrocoDS (Amstrad CPC)'],'Atari_2600_Bestof_Dagli':['RetroArch Atari - 2600 (Stella)','RetroArch Atari - 2600 (Stella 2014)','RetroArch Stella (Atari 2600)','RetroArch Stella 2014 (Atari 2600)'],'Atari_2600_Dagli':['RetroArch Atari - 2600 (Stella)','RetroArch Atari - 2600 (Stella 2014)','RetroArch Stella (Atari 2600)','RetroArch Stella 2014 (Atari 2600)'],'Atari_5200_Dagli':['RetroArch Atari - 5200 (Atari800)','RetroArch Atari800 (Atari 800/Atari 5200)'],'Atari_7800_Dagli':['RetroArch Atari - 7800 (ProSystem)','RetroArch ProSystem (Atari 7800)'],'Atari_800_Dagli':['RetroArch Atari - 5200 (Atari800)','RetroArch Atari800 (Atari 800/Atari 5200)'],'Atari_Jaguar_Dagli':['RetroArch Atari - Jaguar (Virtual Jaguar)','RetroArch Virtual Jaguar (Jaguar)'],'Atari_Lynx_Dagli':['RetroArch Atari - Lynx (Beetle Lynx)','RetroArch Atari - Lynx (Handy)','RetroArch Mednafen Lynx (Lynx)','RetroArch Handy (Lynx)'],'Atari_ST_Dagli':['RetroArch Atari - ST/STE/TT/Falcon (Hatari)','RetroArch Hatari (Atari ST/STE/TT/Falcon)'],'Atomiswave_Dagli':['RetroArch Sega - Dreamcast/NAOMI (Flycast)','Retroarch FlyCast (Dreamcast/Naomi)','Retroarch FlyCast GLES2 (Dreamcast/Naomi)'],'C64_Dagli':['RetroArch Commodore - C64 (VICE x64, fast)','RetroArch Commodore - C64 (Frodo)','RetroArch VICE C64 (C64)','RetroArch Frodo (C64)'],'CDI_Dagli':['RetroArch Multi (MESS 2015)','RetroArch Arcade (MAME - Current)','RetroArch MESS 2014 (MESS 0.160)','RetroArch MAME (Arcade Latest)'],'CannonBall_Dagli':['RetroArch Cannonball','RetroArch CannonBall (Standalone Game)'],'Cavestory_Lefty420':['RetroArch Cave Story (NXEngine)','RetroArch CaveStory (NXEngine)'],'Colecovision_Dagli':['RetroArch MSX/SVI/ColecoVision/SG-1000 (blueMSX)','RetroArch Sega - MS/GG (SMS Plus GX)','RetroArch BlueMSX (MSX)','RetroArch SMS Plus GX (GG/SMS)'],'Dinothawr_Lefty420':['RetroArch Dinothawr','RetroArch Dinothawr (Standalone Game)'],'Doom_Lefty420':['RetroArch Doom (PrBoom)','RetroArch PrBoom (Doom)'],'EasyRPG_Dagli':['RetroArch RPG Maker 2000/2003 (EasyRPG)','RetroArch EasyRPG (RPG Maker 2000/2003)'],'FBN_Dagli':['RetroArch Arcade (FinalBurn Neo)','RetroArch FB Neo (Arcade Latest)'],'GBA_Bestof_Dagli':['RetroArch Nintendo - Game Boy Advance (mGBA)','RetroArch Nintendo - Game Boy Advance (Beetle GBA)','RetroArch mGBA (GBA)','RetroArch Mednafen GBA (GBA)'],'GBA_Hacks_Dagli':['RetroArch Nintendo - Game Boy Advance (mGBA)','RetroArch Nintendo - Game Boy Advance (Beetle GBA)','RetroArch mGBA (GBA)','RetroArch Mednafen GBA (GBA)'],'GBA_Translations_Dagli':['RetroArch Nintendo - Game Boy Advance (mGBA)','RetroArch Nintendo - Game Boy Advance (Beetle GBA)','RetroArch mGBA (GBA)','RetroArch Mednafen GBA (GBA)'],'GBA_Dagli':['RetroArch Nintendo - Game Boy Advance (mGBA)','RetroArch Nintendo - Game Boy Advance (Beetle GBA)','RetroArch mGBA (GBA)','RetroArch Mednafen GBA (GBA)'],'GBC_Bestof_Dagli':['RetroArch Nintendo - Game Boy / Color (Gambatte)','RetroArch Nintendo - Game Boy / Color (fixGB)','RetroArch Gambatte (GB/GBC)','RetroArch fixGB (GB/GBC)'],'GBC_Dagli':['RetroArch Nintendo - Game Boy / Color (Gambatte)','RetroArch Nintendo - Game Boy / Color (fixGB)','RetroArch Gambatte (GB/GBC)','RetroArch fixGB (GB/GBC)'],'GB_Classic_Bestof_Dagli':['RetroArch Nintendo - Game Boy / Color (Gambatte)','RetroArch Nintendo - Game Boy / Color (fixGB)','RetroArch Gambatte (GB/GBC)','RetroArch fixGB (GB/GBC)'],'GB_Classic_Dagli':['RetroArch Nintendo - Game Boy / Color (Gambatte)','RetroArch Nintendo - Game Boy / Color (fixGB)','RetroArch Gambatte (GB/GBC)','RetroArch fixGB (GB/GBC)'],'GameCube_Bestof_Dagli':['RetroArch Nintendo - GameCube / Wii (Dolphin)','Dolphin (GameCube)','RetroArch Dolphin (Wii/Gamecube)'],'GameCube_Dagli':['RetroArch Nintendo - GameCube / Wii (Dolphin)','Dolphin (GameCube)','RetroArch Dolphin (Wii/Gamecube)'],'Game_Gear_Bestof_Dagli':['RetroArch Sega - MS/GG/MD/CD (Genesis Plus GX)','RetroArch Sega - MS/GG/SG-1000 (Gearsystem)','RetroArch Genesis Plus GX (GG/SMS/Gen/PICO/SG-1000)','RetroArch Gearsystem (GG/SMS)'],'Game_Gear_Dagli':['RetroArch Sega - MS/GG/MD/CD (Genesis Plus GX)','RetroArch Sega - MS/GG/SG-1000 (Gearsystem)','RetroArch Genesis Plus GX (GG/SMS/Gen/PICO/SG-1000)','RetroArch Gearsystem (GG/SMS)'],'Game_and_Watch_Dagli':['RetroArch Handheld Electronic (GW)','RetroArch Game and Watch (Game and Watch)'],'Genesis_Bestof_Dagli':['RetroArch Sega - MS/GG/MD/CD (Genesis Plus GX)','RetroArch Sega - MS/MD/CD/32X (PicoDrive)','RetroArch Genesis Plus GX (GG/SMS/Gen/PICO/SG-1000)','RetroArch PicoDrive (SMS/Gen/Sega CD/32X)'],'Genesis_Hacks_Dagli':['RetroArch Sega - MS/GG/MD/CD (Genesis Plus GX)','RetroArch Sega - MS/MD/CD/32X (PicoDrive)','RetroArch Genesis Plus GX (GG/SMS/Gen/PICO/SG-1000)','RetroArch PicoDrive (SMS/Gen/Sega CD/32X)'],'Genesis_Translations_Dagli':['RetroArch Sega - MS/GG/MD/CD (Genesis Plus GX)','RetroArch Sega - MS/MD/CD/32X (PicoDrive)','RetroArch Genesis Plus GX (GG/SMS/Gen/PICO/SG-1000)','RetroArch PicoDrive (SMS/Gen/Sega CD/32X)'],'Genesis_Dagli':['RetroArch Sega - MS/GG/MD/CD (Genesis Plus GX)','RetroArch Sega - MS/MD/CD/32X (PicoDrive)','RetroArch Genesis Plus GX (GG/SMS/Gen/PICO/SG-1000)','RetroArch PicoDrive (SMS/Gen/Sega CD/32X)'],'Intellivision_Dagli':['RetroArch Mattel - Intellivision (FreeIntv)','RetroArch FreeIntv (Intellivision)'],'Karaoke_Dagli':['RetroArch PocketCDG','RetroArch PocketCDG (CDG Music)'],'Lutro_Dagli':['RetroArch Lua Engine (Lutro)','RetroArch Lua Engine (Lutro)'],'MAME_2003_Bestof_Dagli':['RetroArch Arcade (MAME 2003-Plus)','RetroArch Arcade (MAME 2003)','RetroArch MAME 2003 Plus (Arcade 0.78)','RetroArch MAME 2003 (Arcade 0.78)'],'MAME_2003_Plus_Dagli':['RetroArch Arcade (MAME 2003-Plus)','RetroArch Arcade (MAME 2003)','RetroArch MAME 2003 Plus (Arcade 0.78)','RetroArch MAME 2003 (Arcade 0.78)'],'MAME_2003_Dagli':['RetroArch Arcade (MAME 2003-Plus)','RetroArch Arcade (MAME 2003)','RetroArch MAME 2003 Plus (Arcade 0.78)','RetroArch MAME 2003 (Arcade 0.78)'],'MAME_Bestof_Dagli':['RetroArch Arcade (MAME - Current)','RetroArch Arcade (MAME 2015)','RetroArch MAME (Arcade Latest)','RetroArch MAME 2015 (Arcade 0.160)'],'MAME_Dagli':['RetroArch Arcade (MAME - Current)','RetroArch Arcade (MAME 2015)','RetroArch MAME (Arcade Latest)','RetroArch MAME 2015 (Arcade 0.160)'],'MSDOS_Dagli':['RetroArch DOS (DOSBox)','RetroArch DOS (DOSBox-core)','RetroArch DOSBox SVN (DOS)','RetroArch DOSBOX-PURE (DOS)'],'MSX1_Dagli':['RetroArch MSX/SVI/ColecoVision/SG-1000 (blueMSX)','RetroArch Microsoft - MSX (fMSX)','RetroArch BlueMSX (MSX)','RetroArch fMSX (MSX)'],'MSX2_Dagli':['RetroArch MSX/SVI/ColecoVision/SG-1000 (blueMSX)','RetroArch Microsoft - MSX (fMSX)','RetroArch BlueMSX (MSX)','RetroArch fMSX (MSX)'],'Magnavox_O2_Dagli':['RetroArch Magnavox - Odyssey2 / Phillips Videopac+ (O2EM)','RetroArch O2EM (Odyssey2/Videopac)'],'Master_System_Bestof_Dagli':['RetroArch Sega - MS/GG/MD/CD (Genesis Plus GX)','RetroArch Sega - MS/GG/SG-1000 (Gearsystem)','RetroArch Genesis Plus GX (GG/SMS/Gen/PICO/SG-1000)','RetroArch Gearsystem (GG/SMS)'],'Master_System_Dagli':['RetroArch Sega - MS/GG/MD/CD (Genesis Plus GX)','RetroArch Sega - MS/GG/SG-1000 (Gearsystem)','RetroArch Genesis Plus GX (GG/SMS/Gen/PICO/SG-1000)','RetroArch Gearsystem (GG/SMS)'],'N64_Bestof_Dagli':['RetroArch Nintendo - Nintendo 64 (Mupen64Plus-Next)','RetroArch Nintendo - Nintendo 64 (ParaLLEl N64)','RetroArch ParaLLEl (N64)','RetroArch Mupen64Plus (N64)'],'N64_Dagli':['RetroArch Nintendo - Nintendo 64 (Mupen64Plus-Next)','RetroArch Nintendo - Nintendo 64 (ParaLLEl N64)','RetroArch ParaLLEl (N64)','RetroArch Mupen64Plus (N64)'],'NDS_Dagli':['RetroArch Nintendo - DS (DeSmuME)','RetroArch Nintendo - DS (melonDS)','RetroArch DeSmuME (NDS)','RetroArch melonDS (Nintendo DS)'],'NES_Bestof_Dagli':['RetroArch Nintendo - NES / Famicom (Nestopia UE)','RetroArch Nintendo - NES / Famicom (FCEUmm)','RetroArch QuickNES (NES)','RetroArch FCEUmm (NES)'],'NES_Hacks_Dagli':['RetroArch Nintendo - NES / Famicom (Nestopia UE)','RetroArch Nintendo - NES / Famicom (FCEUmm)','RetroArch QuickNES (NES)','RetroArch FCEUmm (NES)'],'NES_Translations_Dagli':['RetroArch Nintendo - NES / Famicom (Nestopia UE)','RetroArch Nintendo - NES / Famicom (FCEUmm)','RetroArch QuickNES (NES)','RetroArch FCEUmm (NES)'],'NES_Dagli':['RetroArch Nintendo - NES / Famicom (Nestopia UE)','RetroArch Nintendo - NES / Famicom (FCEUmm)','RetroArch QuickNES (NES)','RetroArch FCEUmm (NES)'],'NGPC_Dagli':['RetroArch SNK - Neo Geo Pocket / Color (Beetle NeoPop)','RetroArch SNK - Neo Geo Pocket / Color (RACE)','RetroArch Mednafen NeoPop (NGP/NGPC)','RetroArch RACE (NGP/NGPC)'],'Naomi1_Dagli':['RetroArch Sega - Dreamcast/NAOMI (Flycast)','Retroarch FlyCast (Dreamcast/Naomi)'],'Neo_Geo_CD_Dagli':['RetroArch Arcade (FinalBurn Neo)','RetroArch SNK - Neo Geo CD (NeoCD)','RetroArch FB Neo (Arcade Latest)','RetroArch NeoCD (Neo Geo CD)'],'OpenLara_Dagli':['RetroArch Tomb Raider (OpenLara)','RetroArch OpenLara (Tomb Raider)'],'PCE_CD_Dagli':['RetroArch NEC - PC Engine / SuperGrafx / CD (Beetle PCE)','RetroArch NEC - PC Engine / CD (Beetle PCE FAST)','RetroArch Mednafen PCE FAST (PCE/TG16)','RetroArch Mednafen PCE (PCE/TG16)'],'PCE_SuperGrafx_Dagli':['RetroArch NEC - PC Engine SuperGrafx (Beetle SuperGrafx)','RetroArch NEC - PC Engine / SuperGrafx / CD (Beetle PCE)','RetroArch Mednafen SuperGrafx (PCE SuperGrafx)','RetroArch Mednafen PCE FAST (PCE/TG16)'],'PS1_Bestof_Dagli':['RetroArch Sony - PlayStation (Beetle PSX HW)','RetroArch Sony - PlayStation (Beetle PSX)','RetroArch PCSX ReArmed (PS1)','RetroArch Mednafen PSX HW (PS1)'],'PS1_Dagli':['RetroArch Sony - PlayStation (Beetle PSX HW)','RetroArch Sony - PlayStation (Beetle PSX)','RetroArch PCSX ReArmed (PS1)','RetroArch Mednafen PSX HW (PS1)'],'PSP_Dagli':['RetroArch Sony - PlayStation Portable (PPSSPP)','RetroArch PPSSPP (PSP)','PPSSPP (PlayStation Portable)'],'Pokemon_Mini_Dagli':['RetroArch Nintendo - Pokemon Mini (PokeMini)','RetroArch Pokemon Mini (PokeMini)'],'PowderToy_Dagli':['RetroArch The Powder Toy','RetroArch PowderToy (Standalone Game)'],'Quake_Lefty420':['RetroArch Quake (TyrQuake)','RetroArch TyrQuake (Quake)'],'REminiscence_Dagli':['RetroArch Flashback (REminiscence)','RetroArch REminiscence (Standalone Game)'],'RickDangerous_Dagli':['RetroArch Rick Dangerous (XRick)','RetroArch XRick (Rick Dangerous)'],'SCUMMVM_Bestof_Dagli':['RetroArch ScummVM','RetroArch ScummVM (Various)'],'SCUMMVM_Dagli':['RetroArch ScummVM','RetroArch ScummVM (Various)'],'SNES_Bestof_Dagli':['RetroArch Nintendo - SNES / SFC (bsnes)','RetroArch Nintendo - SNES / SFC (Snes9x - Current)','RetroArch SNES9x (SNES)','RetroArch SNES Higan (SNES)'],'SNES_Hacks_Dagli':['RetroArch Nintendo - SNES / SFC (bsnes)','RetroArch Nintendo - SNES / SFC (Snes9x - Current)','RetroArch SNES9x (SNES)','RetroArch SNES Higan (SNES)'],'SNES_Translations_Dagli':['RetroArch Nintendo - SNES / SFC (bsnes)','RetroArch Nintendo - SNES / SFC (Snes9x - Current)','RetroArch SNES9x (SNES)','RetroArch SNES Higan (SNES)'],'SNES_Dagli':['RetroArch Nintendo - SNES / SFC (bsnes)','RetroArch Nintendo - SNES / SFC (Snes9x - Current)','RetroArch SNES9x (SNES)','RetroArch SNES Higan (SNES)'],'Satellaview_Dagli':['RetroArch Nintendo - SNES / SFC (bsnes)','RetroArch Nintendo - SNES / SFC (Snes9x - Current)','RetroArch SNES9x (SNES)','RetroArch SNES Higan (SNES)'],'Sega_CD_Dagli':['RetroArch Sega - MS/GG/MD/CD (Genesis Plus GX)','RetroArch Sega - MS/MD/CD/32X (PicoDrive)','RetroArch Genesis Plus GX (GG/SMS/Gen/PICO/SG-1000)','RetroArch PicoDrive (SMS/Gen/Sega CD/32X)'],'Sega_Dreamcast_Dagli':['RetroArch Sega - Dreamcast/NAOMI (Flycast)','Retroarch FlyCast (Dreamcast/Naomi)'],'Sega_SG1000_Dagli':['RetroArch Sega - MS/GG/MD/CD (Genesis Plus GX)','RetroArch Sega - MS/GG (SMS Plus GX)','RetroArch Genesis Plus GX (GG/SMS/Gen/PICO/SG-1000)','RetroArch SMS Plus GX (GG/SMS)'],'Sega_Saturn_Dagli':['RetroArch Sega - Saturn (Beetle Saturn)','RetroArch Sega - Saturn (Yabause)','RetroArch Mednafen Saturn (Saturn)','RetroArch Yabasanshiro (Saturn)'],'TG16_Bestof_Dagli':['RetroArch NEC - PC Engine / SuperGrafx / CD (Beetle PCE)','RetroArch NEC - PC Engine / CD (Beetle PCE FAST)','RetroArch Mednafen PCE FAST (PCE/TG16)','RetroArch Mednafen PCE (PCE/TG16)'],'TG16_Dagli':['RetroArch NEC - PC Engine / SuperGrafx / CD (Beetle PCE)','RetroArch NEC - PC Engine / CD (Beetle PCE FAST)','RetroArch Mednafen PCE FAST (PCE/TG16)','RetroArch Mednafen PCE (PCE/TG16)'],'TIC80_Dagli':['RetroArch TIC-80','RetroArch TIC80 (TIC-80)'],'Vectrex_Dagli':['RetroArch GCE - Vectrex (vecx)','RetroArch VECX (Vectrex)'],'VirtualBoy_Dagli':['RetroArch Nintendo - Virtual Boy (Beetle VB)','RetroArch Mednafen VB (VirtualBoy)'],'Wii_Bestof_Dagli':['RetroArch Nintendo - GameCube / Wii (Dolphin)','Dolphin (GameCube)','RetroArch Dolphin (Wii/Gamecube)'],'Wii_Dagli':['RetroArch Nintendo - GameCube / Wii (Dolphin)','Dolphin (GameCube)','RetroArch Dolphin (Wii/Gamecube)'],'Win31_Dagli':['RetroArch DOS (DOSBox)','RetroArch DOS (DOSBox-core)','RetroArch DOSBox SVN (DOS)','RetroArch DOSBOX-PURE (DOS)'],'Wolfenstein_Dagli':['RetroArch Wolfenstein 3D (ECWolf)','RetroArch ECWolf (Wolfenstein 3D)'],'Wonderswan_Color_Dagli':['RetroArch Bandai - WonderSwan/Color (Beetle Cygne)','RetroArch Mednafen Cygne (WonderSwan/WonderSwan Color)'],'Wonderswan_Dagli':['RetroArch Bandai - WonderSwan/Color (Beetle Cygne)','RetroArch Mednafen Cygne (WonderSwan/WonderSwan Color)'],'ZX_Spectrum_Dagli':['RetroArch Sinclair - ZX Spectrum (Fuse)','RetroArch FUSE (Spectrum)'],'eXoDOS_Dagli':['RetroArch DOS (DOSBox)','RetroArch DOS (DOSBox-core)','RetroArch DOSBox (DOS)','RetroArch DOSBOX-PURE (DOS)']}
RP_DEFAULTS = {'32X_Dagli':['game.libretro.picodrive'],'3DO_Dagli':['game.libretro.opera'],'Amiga_Bestof':['game.libretro.uae','game.libretro.uae4arm'],'Amiga_CD32_Dagli':['game.libretro.uae','game.libretro.uae4arm'],'Amiga_Dagli':['game.libretro.uae','game.libretro.uae4arm'],'Amstrad_CPC_Dagli':['game.libretro.cap32','game.libretro.crocods'],'Atari_2600_Bestof_Dagli':['game.libretro.stella'],'Atari_2600_Dagli':['game.libretro.stella'],'Atari_5200_Dagli':['game.libretro.atari800'],'Atari_7800_Dagli':['game.libretro.prosystem'],'Atari_800_Dagli':['game.libretro.atari800'],'Atari_Jaguar_Dagli':['game.libretro.virtualjaguar'],'Atari_Lynx_Dagli':['game.libretro.beetle-lynx','game.libretro.handy'],'Atari_ST_Dagli':['game.libretro.hatari'],'Atomiswave_Dagli':['game.libretro.flycast'],'C64_Dagli':['game.libretro.vice','game.libretro.frodo'],'CDI_Dagli':['game.libretro.mame'],'CannonBall_Dagli':['game.libretro.cannonball'],'Cavestory_Lefty420':['game.libretro.nx'],'Colecovision_Dagli':['game.libretro.bluemsx','game.libretro.smsplus-gx'],'Dinothawr_Lefty420':['game.libretro.dinothawr'],'Doom_Lefty420':['game.libretro.prboom'],'EasyRPG_Dagli':['game.libretro.easyrpg'],'FBN_Dagli':['game.libretro.fbneo','game.libretro.fbalpha2012'],'GBA_Bestof_Dagli':['game.libretro.mgba','game.libretro.beetle-gba'],'GBA_Hacks_Dagli':['game.libretro.mgba','game.libretro.beetle-gba'],'GBA_Translations_Dagli':['game.libretro.mgba','game.libretro.beetle-gba'],'GBA_Dagli':['game.libretro.mgba','game.libretro.beetle-gba'],'GBC_Bestof_Dagli':['game.libretro.gambatte','game.libretro.tgbdual'],'GBC_Dagli':['game.libretro.gambatte','game.libretro.tgbdual'],'GB_Classic_Bestof_Dagli':['game.libretro.gambatte','game.libretro.tgbdual'],'GB_Classic_Dagli':['game.libretro.gambatte','game.libretro.tgbdual'],'GameCube_Bestof_Dagli':['game.libretro.dolphin'],'GameCube_Dagli':['game.libretro.dolphin'],'Game_Gear_Bestof_Dagli':['game.libretro.genplus','game.libretro.smsplus-gx'],'Game_Gear_Dagli':['game.libretro.genplus','game.libretro.smsplus-gx'],'Game_and_Watch_Dagli':['game.libretro.gw'],'Genesis_Bestof_Dagli':['game.libretro.genplus','game.libretro.picodrive'],'Genesis_Hacks_Dagli':['game.libretro.genplus','game.libretro.picodrive'],'Genesis_Translations_Dagli':['game.libretro.genplus','game.libretro.picodrive'],'Genesis_Dagli':['game.libretro.genplus','game.libretro.picodrive'],'Intellivision_Dagli':['game.libretro.freeintv'],'Karaoke_Dagli':['game.libretro.pocketcdg'],'Lutro_Dagli':['game.libretro.lutro'],'MAME_2003_Bestof_Dagli':['game.libretro.mame2003_plus','game.libretro.mame2003'],'MAME_2003_Plus_Dagli':['game.libretro.mame2003_plus','game.libretro.mame2003'],'MAME_2003_Dagli':['game.libretro.mame2003_plus','game.libretro.mame2003'],'MAME_Bestof_Dagli':['game.libretro.mame','game.libretro.mame2015'],'MAME_Dagli':['game.libretro.mame','game.libretro.mame2015'],'MSDOS_Dagli':['game.libretro.dosbox','game.libretro.dosbox-pure'],'MSX1_Dagli':['game.libretro.bluemsx','game.libretro.fmsx'],'MSX2_Dagli':['game.libretro.bluemsx','game.libretro.fmsx'],'Magnavox_O2_Dagli':['game.libretro.o2em'],'Master_System_Bestof_Dagli':['game.libretro.genplus','game.libretro.smsplus-gx'],'Master_System_Dagli':['game.libretro.genplus','game.libretro.smsplus-gx'],'N64_Bestof_Dagli':['game.libretro.parallel_n64','game.libretro.mupen64plus-nx'],'N64_Dagli':['game.libretro.parallel_n64','game.libretro.mupen64plus-nx'],'NDS_Dagli':['game.libretro.desmume','game.libretro.melonds'],'NES_Bestof_Dagli':['game.libretro.bnes','game.libretro.fceumm'],'NES_Hacks_Dagli':['game.libretro.bnes','game.libretro.fceumm'],'NES_Translations_Dagli':['game.libretro.bnes','game.libretro.fceumm'],'NES_Dagli':['game.libretro.bnes','game.libretro.fceumm'],'NGPC_Dagli':['game.libretro.beetle-ngp','game.libretro.race'],'Naomi1_Dagli':['game.libretro.flycast'],'Neo_Geo_CD_Dagli':['game.libretro.fbneo'],'OpenLara_Dagli':['game.libretro.openlara'],'PCE_CD_Dagli':['game.libretro.beetle-pce-fast'],'PCE_SuperGrafx_Dagli':['game.libretro.beetle-pce-fast'],'PS1_Bestof_Dagli':['game.libretro.beetle-psx','game.libretro.pcsx-rearmed'],'PS1_Dagli':['game.libretro.beetle-psx','game.libretro.pcsx-rearmed'],'PSP_Dagli':['game.libretro.ppsspp'],'Pokemon_Mini_Dagli':['game.libretro.pokemini'],'PowderToy_Dagli':['game.libretro.thepowdertoy'],'Quake_Lefty420':['game.libretro.tyrquake'],'REminiscence_Dagli':['game.libretro.reminiscence'],'RickDangerous_Dagli':[],'SCUMMVM_Bestof_Dagli':['game.libretro.scummvm'],'SCUMMVM_Dagli':['game.libretro.scummvm'],'SNES_Bestof_Dagli':['game.libretro.snes9x','game.libretro.bsnes-mercury-balanced'],'SNES_Hacks_Dagli':['game.libretro.snes9x','game.libretro.bsnes-mercury-balanced'],'SNES_Translations_Dagli':['game.libretro.snes9x','game.libretro.bsnes-mercury-balanced'],'SNES_Dagli':['game.libretro.snes9x','game.libretro.bsnes-mercury-balanced'],'Satellaview_Dagli':['game.libretro.snes9x','game.libretro.bsnes-mercury-balanced'],'Sega_CD_Dagli':['game.libretro.genplus','game.libretro.picodrive'],'Sega_Dreamcast_Dagli':['game.libretro.flycast'],'Sega_SG1000_Dagli':['game.libretro.genplus','game.libretro.smsplus-gx'],'Sega_Saturn_Dagli':['game.libretro.beetle-saturn','game.libretro.yabause'],'TG16_Bestof_Dagli':['game.libretro.beetle-pce-fast'],'TG16_Dagli':['game.libretro.beetle-pce-fast'],'TIC80_Dagli':[],'Vectrex_Dagli':['game.libretro.vecx'],'VirtualBoy_Dagli':['game.libretro.beetle-vb'],'Wii_Bestof_Dagli':['game.libretro.dolphin'],'Wii_Dagli':['game.libretro.dolphin'],'Win31_Dagli':['game.libretro.dosbox','game.libretro.dosbox-pure'],'Wolfenstein_Dagli':['game.libretro.ecwolf'],'Wonderswan_Color_Dagli':['game.libretro.beetle-wswan'],'Wonderswan_Dagli':['game.libretro.beetle-wswan'],'ZX_Spectrum_Dagli':['game.libretro.fuse'],'eXoDOS_Dagli':['game.libretro.dosbox','game.libretro.dosbox-pure']}
# clear_mem_cache('PlayStation Store_script_started') #For testing
if not get_mem_cache('PlayStation Store_script_started'):
	set_mem_cache('PlayStation Store_script_started','true')
	xbmc.log(msg='PlayStation Store:  Wizard script started', level=xbmc.LOGDEBUG)
	PlayStation Store_addon_wizard.handle.setSetting(id='PlayStation Store_run_wizard',value='false')
	wizard_settings = dict()
	current_dialog = xbmcgui.Dialog()
	xbmc.playSFX(START_SOUND,False)
	ok_ret = current_dialog.ok(loc_str(30005),loc_str(30382))
	if not (PlayStation Store_addon_wizard.handle.getSetting(id='PlayStation Store_setting_enable_login')=='0' and PlayStation Store_addon_wizard.handle.getSetting(id='PlayStation Store_setting_ia_username') and PlayStation Store_addon_wizard.handle.getSetting(id='PlayStation Store_setting_ia_password') and re.match(EMAIL_RE,PlayStation Store_addon_wizard.handle.getSetting(id='PlayStation Store_setting_ia_username'))):
		wizard_settings['enter_credentials'] = current_dialog.select(loc_str(30383),[loc_str(30200),loc_str(30204)])
		if wizard_settings.get('enter_credentials')==0:
			xbmc.playSFX(POS_SOUND,False)
			if PlayStation Store_addon_wizard.handle.getSetting(id='PlayStation Store_setting_ia_username'):
				wizard_settings['archive_org_email'] = current_dialog.input(heading=loc_str(30023),defaultt=PlayStation Store_addon_wizard.handle.getSetting(id='PlayStation Store_setting_ia_username'))
			else:
				wizard_settings['archive_org_email'] = current_dialog.input(heading=loc_str(30023))
			if wizard_settings.get('archive_org_email') and re.match(EMAIL_RE,wizard_settings.get('archive_org_email')):
				wizard_settings['archive_org_password'] = current_dialog.input(heading=loc_str(30024),option=xbmcgui.ALPHANUM_HIDE_INPUT)
			else:
				xbmc.playSFX(NEG_SOUND,False)
				ok_ret = current_dialog.ok(loc_str(30005),loc_str(30384))
				if PlayStation Store_addon_wizard.handle.getSetting(id='PlayStation Store_setting_ia_username'):
					wizard_settings['archive_org_email'] = current_dialog.input(heading=loc_str(30023),defaultt=PlayStation Store_addon_wizard.handle.getSetting(id='PlayStation Store_setting_ia_username'))
				else:
					wizard_settings['archive_org_email'] = current_dialog.input(heading=loc_str(30023))
				if PlayStation Store_addon_wizard.handle.getSetting(id='PlayStation Store_setting_ia_password'):
					wizard_settings['archive_org_password'] = current_dialog.input(heading=loc_str(30024),defaultt=PlayStation Store_addon_wizard.handle.getSetting(id='PlayStation Store_setting_ia_password'),option=xbmcgui.ALPHANUM_HIDE_INPUT)
				else:
					wizard_settings['archive_org_password'] = current_dialog.input(heading=loc_str(30024),option=xbmcgui.ALPHANUM_HIDE_INPUT)
		if wizard_settings.get('archive_org_email') and wizard_settings.get('archive_org_password') and re.match(EMAIL_RE,wizard_settings.get('archive_org_email')): 
			xbmc.log(msg='PlayStation Store:  Wizard enabled login', level=xbmc.LOGDEBUG)
			PlayStation Store_addon_wizard.handle.setSetting(id='PlayStation Store_setting_enable_login',value='0')
			PlayStation Store_addon_wizard.handle.setSetting(id='PlayStation Store_setting_ia_username',value=wizard_settings.get('archive_org_email'))
			PlayStation Store_addon_wizard.handle.setSetting(id='PlayStation Store_setting_ia_password',value=wizard_settings.get('archive_org_password'))
		else:
			xbmc.log(msg='PlayStation Store:  Wizard did not enable login', level=xbmc.LOGDEBUG)
			xbmc.playSFX(NEG_SOUND,False)
			PlayStation Store_addon_wizard.handle.setSetting(id='PlayStation Store_setting_enable_login',value='1')
			ok_ret = current_dialog.ok(loc_str(30005),loc_str(30385))
	else:
		xbmc.log(msg='PlayStation Store:  Wizard found existing login settings', level=xbmc.LOGDEBUG)
	wizard_settings['wizard_launcher'] = current_dialog.select(loc_str(30333),[loc_str(30128),loc_str(30363)])
	loop = True
	while loop:
		if wizard_settings.get('wizard_launcher')<0:
			if current_dialog.yesno(loc_str(30386),loc_str(30386)):
				loop = False
				break
			else:
				wizard_settings['wizard_launcher'] = current_dialog.select(loc_str(30333),[loc_str(30128),loc_str(30363)])
		else:
			loop = False
			break
	launch_type = None
	if wizard_settings.get('wizard_launcher')==1:
	# if PlayStation Store_addon_wizard.handle.getSetting(id='PlayStation Store_wizard_launcher')=='0': #External
		launch_type = loc_str(30206)
		xbmc.log(msg='PlayStation Store:  Wizard script running for external launching', level=xbmc.LOGDEBUG)
		options = [loc_str(30116),loc_str(30117),loc_str(30118),loc_str(30123),loc_str(30514),loc_str(30582)]
		if PlayStation Store_addon_wizard.handle.getSetting(id='PlayStation Store_external_user_external_env')=='0':
			loop = True
			while loop:
				wizard_settings['ext_env'] = current_dialog.select(loc_str(30025),options)
				if wizard_settings.get('ext_env') != -1:
					xbmc.log(msg='PlayStation Store:  Wizard external environment set to %(env)s'%{'env':options[wizard_settings.get('ext_env')]}, level=xbmc.LOGDEBUG)
					PlayStation Store_addon_wizard.handle.setSetting(id='PlayStation Store_external_user_external_env',value=str(wizard_settings.get('ext_env')+1))
					loop = False
					break
				else:
					if current_dialog.yesno(loc_str(30386),loc_str(30386)):
						loop = False
		else:
			xbmc.log(msg='PlayStation Store:  External environment already set to %(env)s'%{'env':options[int(PlayStation Store_addon_wizard.handle.getSetting(id='PlayStation Store_external_user_external_env'))-1]}, level=xbmc.LOGDEBUG)
		if PlayStation Store_addon_wizard.handle.getSetting(id='PlayStation Store_external_user_external_env')!='0' and int(PlayStation Store_addon_wizard.handle.getSetting(id='PlayStation Store_external_user_external_env')) in [1,2,3] and not PlayStation Store_addon_wizard.handle.getSetting(id='PlayStation Store_external_path_to_retroarch'):
			start_path = ''
			POSSIBLE_RA_LOCATIONS = [os.path.join('/Applications','RetroArch.app','Contents','MacOS','RetroArch'),os.path.join('usr','bin','retroarch'),os.path.join('usr','local','bin','retroarch'),os.path.join(os.path.expanduser('~'),'bin','retroarch'),os.path.join(os.path.expanduser('~'),'ra','usr','local','bin','retroarch'),os.path.join('var','lib','flatpak','app','org.libretro.RetroArch','current','active','files','bin','retroarch'),os.path.join('C:','Program Files (x86)','Retroarch','retroarch.exe'),os.path.join('C:','Program Files','Retroarch','retroarch.exe'),os.path.join('home','kodi','bin','retroarch'),os.path.join('opt','retropie','emulators','retroarch','bin','retroarch'),os.path.join('opt','retroarch','bin','retroarch')]
			try:
				POSSIBLE_RA_LOCATIONS = [shutil.which('retroarch')]+POSSIBLE_RA_LOCATIONS
			except:
				xbmc.log(msg='PlayStation Store:  shutil which failed', level=xbmc.LOGDEBUG)
			if any([os.path.exists(x) for x in POSSIBLE_RA_LOCATIONS if x]):
				start_path = [x for x in POSSIBLE_RA_LOCATIONS if x and os.path.exists(x)][0]
			loop = True
			while loop:
				wizard_settings['ra_app_location'] = current_dialog.browse(type=1,heading=loc_str(30028),shares='',defaultt=start_path)
				if wizard_settings.get('ra_app_location') and os.path.exists(str(wizard_settings.get('ra_app_location'))):
					xbmc.log(msg='PlayStation Store:  Wizard RA app location set to %(value)s'%{'value':wizard_settings.get('ra_app_location')}, level=xbmc.LOGDEBUG)
					PlayStation Store_addon_wizard.handle.setSetting(id='PlayStation Store_external_path_to_retroarch',value=str(wizard_settings.get('ra_app_location')))
					loop = False
					break
				else:
					if current_dialog.yesno(loc_str(30386),loc_str(30386)):
						loop = False
		elif PlayStation Store_addon_wizard.handle.getSetting(id='PlayStation Store_external_user_external_env')!='0' and int(PlayStation Store_addon_wizard.handle.getSetting(id='PlayStation Store_external_user_external_env')) in [1,2,3] and PlayStation Store_addon_wizard.handle.getSetting(id='PlayStation Store_external_path_to_retroarch'):
			xbmc.log(msg='PlayStation Store:  Retroarch app location already set to %(value)s'%{'value':PlayStation Store_addon_wizard.handle.getSetting(id='PlayStation Store_external_path_to_retroarch')}, level=xbmc.LOGDEBUG)
		if PlayStation Store_addon_wizard.handle.getSetting(id='PlayStation Store_external_user_external_env')!='0' and int(PlayStation Store_addon_wizard.handle.getSetting(id='PlayStation Store_external_user_external_env')) in [1,2,3,4,5,6] and not PlayStation Store_addon_wizard.handle.getSetting(id='PlayStation Store_external_path_to_retroarch_cfg'):
			start_path = ''
			POSSIBLE_CFG_LOCATIONS = [os.path.join(os.path.expanduser('~'),'Library','Application Support','RetroArch','config','retroarch.cfg'),os.path.join('C:','Program Files (x86)','Retroarch','retroarch.cfg'),os.path.join('C:','Program Files','Retroarch','retroarch.cfg'),os.path.join(os.path.expanduser('~'),'.config','retroarch','retroarch.cfg'),os.path.join(os.path.expanduser('~'),'AppData','Roaming','RetroArch','retroarch.cfg'),os.path.join(os.path.expanduser('~'),'.var','app','org.libretro.RetroArch','config','retroarch','retroarch.cfg'),os.path.join('opt','retropie','configs','all','retroarch.cfg'),os.path.join('mnt','internal_sd','Android','data','com.retroarch','files','retroarch.cfg'),os.path.join('sdcard','Android','data','com.retroarch','files','retroarch.cfg'),os.path.join('data','data','com.retroarch','retroarch.cfg'),os.path.join('data','data','com.retroarch','files','retroarch.cfg'),os.path.join('mnt','internal_sd','Android','data','com.retroarch.aarch64','files','retroarch.cfg'),os.path.join('sdcard','Android','data','com.retroarch.aarch64','files','retroarch.cfg'),os.path.join('data','user','0','com.retroarch.aarch64','retroarch.cfg'),os.path.join('data','user','0','com.retroarch.aarch64','files','retroarch.cfg'),os.path.join('mnt','internal_sd','Android','data','com.retroarch.ra32','files','retroarch.cfg'),os.path.join('sdcard','Android','data','com.retroarch.ra32','files','retroarch.cfg'),os.path.join('data','data','com.retroarch.ra32','retroarch.cfg'),os.path.join('data','data','com.retroarch.ra32','files','retroarch.cfg')]
			if any([os.path.exists(x) for x in POSSIBLE_CFG_LOCATIONS if x]):
				start_path = [x for x in POSSIBLE_CFG_LOCATIONS if x and os.path.exists(x)][0]
			loop = True
			while loop:
				wizard_settings['ra_cfg_location'] = current_dialog.browse(type=1,heading=loc_str(30030),shares='',defaultt=start_path)
				if wizard_settings.get('ra_cfg_location') and os.path.exists(str(wizard_settings.get('ra_cfg_location'))):
					xbmc.log(msg='PlayStation Store:  Wizard RA CFG location set to %(value)s'%{'value':wizard_settings.get('ra_cfg_location')}, level=xbmc.LOGDEBUG)
					PlayStation Store_addon_wizard.handle.setSetting(id='PlayStation Store_external_path_to_retroarch_cfg',value=str(wizard_settings.get('ra_cfg_location')))
					loop = False
					break
				else:
					if current_dialog.yesno(loc_str(30386),loc_str(30386)):
						loop = False
		elif PlayStation Store_addon_wizard.handle.getSetting(id='PlayStation Store_external_user_external_env')!='0' and int(PlayStation Store_addon_wizard.handle.getSetting(id='PlayStation Store_external_user_external_env')) in [1,2,3,4,5,6] and PlayStation Store_addon_wizard.handle.getSetting(id='PlayStation Store_external_path_to_retroarch_cfg'):
			xbmc.log(msg='PlayStation Store:  Retroarch CFG location already set to %(value)s'%{'value':PlayStation Store_addon_wizard.handle.getSetting(id='PlayStation Store_external_path_to_retroarch_cfg')}, level=xbmc.LOGDEBUG)
		if int(PlayStation Store_addon_wizard.handle.getSetting(id='PlayStation Store_external_user_external_env')) in [1,2,3]:
			if current_dialog.yesno(loc_str(30005),loc_str(30617)):
				PlayStation Store_addon_wizard.handle.setSetting(id='PlayStation Store_netplay_enable_netplay_launch',value='0')
				PlayStation Store_addon_wizard.handle.setSetting(id='PlayStation Store_netplay_show_netplay_lobby',value='0')
				wizard_settings['netplay_nickname'] = current_dialog.input(heading=loc_str(30040),defaultt=PlayStation Store_addon_wizard.handle.getSetting(id='PlayStation Store_netplay_nickname'))
				if wizard_settings.get('netplay_nickname'):
					PlayStation Store_addon_wizard.handle.setSetting(id='PlayStation Store_netplay_nickname',value=wizard_settings.get('netplay_nickname'))
			else:
				PlayStation Store_addon_wizard.handle.setSetting(id='PlayStation Store_netplay_enable_netplay_launch',value='1')
				PlayStation Store_addon_wizard.handle.setSetting(id='PlayStation Store_netplay_show_netplay_lobby',value='1')
		else:
			PlayStation Store_addon_wizard.handle.setSetting(id='PlayStation Store_netplay_enable_netplay_launch',value='1')
			PlayStation Store_addon_wizard.handle.setSetting(id='PlayStation Store_netplay_show_netplay_lobby',value='1')

		if current_dialog.yesno(loc_str(30005),loc_str(30387)):
			wizard_settings['game_list'] = dict()
			PlayStation Store_addon_wizard = PlayStation Store_addon() #Reload settings based on wizard entries
			ext_commands = PlayStation Store_addon_wizard.get_ext_launch_cmds()
			if ext_commands:
				dp = xbmcgui.DialogProgress()
				dp.create(loc_str(30377),loc_str(30379))
				dp.update(0,loc_str(30379))
				# current_bg_dialog = xbmcgui.DialogProgressBG()
				# current_bg_dialog.create(loc_str(30377),loc_str(30379))
				for ii,hh in enumerate(PlayStation Store_addon_wizard.directory.get('userdata').get('dat_files').get('header')):
					if hh and hh.get('emu_visibility') and hh.get('emu_visibility') != 'hidden':
						current_fn = PlayStation Store_addon_wizard.directory.get('userdata').get('dat_files').get('files')[ii]
						game_list_id = current_fn.name.replace(current_fn.suffix,'')
						wizard_settings['game_list'][game_list_id] = dict()
						wizard_settings['game_list'][game_list_id]['success'] = False
						wizard_settings['game_list'][game_list_id]['command'] = None
						wizard_settings['game_list'][game_list_id]['command_name'] = None
						dp.update(int(100*(ii+1)/(len(PlayStation Store_addon_wizard.directory.get('userdata').get('dat_files').get('header'))+.001)),loc_str(30377)+'[CR]'+loc_str(30379))
						# current_bg_dialog.update(int(100*(ii+1)/(len(PlayStation Store_addon_wizard.directory.get('userdata').get('dat_files').get('header'))+.001)),loc_str(30377),loc_str(30379))
						if dp.iscanceled():
							xbmc.log(msg='PlayStation Store:  User cancelled the wizard mid process', level=xbmc.LOGDEBUG)
							wizard_settings['game_list'][game_list_id]['success'] = False
							wizard_settings['game_list'][game_list_id]['command'] = None
							wizard_settings['game_list'][game_list_id]['command_name'] = None
							break
						if EXT_DEFAULTS.get(game_list_id) and any([any([x.get('@name')==y for y in EXT_DEFAULTS.get(game_list_id)]) for x in ext_commands if x and x.get('@name')]):
							current_command_name = next(iter([x for x in EXT_DEFAULTS.get(game_list_id) if x in [y.get('@name') for y in ext_commands] if x]),'none')
							current_command = next(iter([x.get('command') for x in ext_commands if x and x.get('@name') == current_command_name]),'none')
							if PlayStation Store_addon_wizard.game_lists.update_game_list_header(game_list_id,header_key='emu_launcher',header_value='external',confirm_update=False):
								xbmc.log(msg='PlayStation Store:  Wizard update launcher for game list %(value)s to External'%{'value':game_list_id}, level=xbmc.LOGDEBUG)
								if PlayStation Store_addon_wizard.game_lists.update_game_list_header(game_list_id,header_key='emu_ext_launch_cmd',header_value=current_command,confirm_update=False):
									xbmc.log(msg='PlayStation Store:  Wizard update launch command for game list %(value)s to %(ext_command)s'%{'value':game_list_id,'ext_command':current_command}, level=xbmc.LOGDEBUG)
									wizard_settings['game_list'][game_list_id]['success'] = True
									wizard_settings['game_list'][game_list_id]['command'] = current_command
									wizard_settings['game_list'][game_list_id]['command_name'] = current_command_name
						else:
							xbmc.log(msg='PlayStation Store:  Wizard did not find a default external launch command for %(value)s'%{'value':game_list_id}, level=xbmc.LOGERROR)
				dp.close()
				del dp
				# current_bg_dialog.close()
				# xbmc.executebuiltin('Dialog.Close(extendedprogressdialog,true)')
				# check_and_close_notification(notification_id='extendedprogressdialog')
				# del current_bg_dialog
			else:
				ok_ret = current_dialog.ok(loc_str(30005),loc_str(30388))
	elif wizard_settings.get('wizard_launcher')==0:
		launch_type = loc_str(30364)
		xbmc.log(msg='PlayStation Store:  Wizard script running for Retroplayer launching', level=xbmc.LOGDEBUG)
		#Turn off netplay for Retroplayer setup for now
		PlayStation Store_addon_wizard.handle.setSetting(id='PlayStation Store_netplay_enable_netplay_launch',value='1')
		PlayStation Store_addon_wizard.handle.setSetting(id='PlayStation Store_netplay_show_netplay_lobby',value='1')
		yesno_ret = current_dialog.yesnocustom(loc_str(30005),loc_str(30390),loc_str(30389))
		if yesno_ret in [1,2]:
			wizard_settings['game_list'] = dict()
			PlayStation Store_addon_wizard = PlayStation Store_addon() #Reload settings based on wizard entries
		if yesno_ret == 1:
			addons_available = []
			try:
				json_query = json.loads(xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Addons.GetAddons","params":{"type":"kodi.gameclient", "enabled": true}, "id": "1"}'))
			except Exception as exc:
				xbmc.log(msg='PlayStation Store:  Error executing JSONRPC command.  Exception %(exc)s' % {'exc': exc}, level=xbmc.LOGERROR)
				json_query = None
			if json_query and json_query.get('result') and json_query.get('result').get('addons'):
				addons_available = sorted([x.get('addonid') for x in json_query.get('result').get('addons') if x and x.get('addonid')!='game.libretro'])
			# current_bg_dialog = xbmcgui.DialogProgressBG()
			# current_bg_dialog.create(loc_str(30377),loc_str(30379))
			dp = xbmcgui.DialogProgress()
			dp.create(loc_str(30377),loc_str(30379))
			# xbmcgui.Window(xbmcgui.getCurrentWindowDialogId()).setProperty('PlayStation Store_wizard_progress','true') #Keep track of which window this is
			dp.update(0,loc_str(30379))
			for ii,hh in enumerate(PlayStation Store_addon_wizard.directory.get('userdata').get('dat_files').get('header')):
				if hh and hh.get('emu_visibility') and hh.get('emu_visibility') != 'hidden':
					current_fn = PlayStation Store_addon_wizard.directory.get('userdata').get('dat_files').get('files')[ii]
					game_list_id = current_fn.name.replace(current_fn.suffix,'')
					wizard_settings['game_list'][game_list_id] = dict()
					wizard_settings['game_list'][game_list_id]['success'] = False
					wizard_settings['game_list'][game_list_id]['command'] = None
					wizard_settings['game_list'][game_list_id]['command_name'] = None
					dp.update(int(100*(ii+1)/(len(PlayStation Store_addon_wizard.directory.get('userdata').get('dat_files').get('header'))+.001)),loc_str(30377)+'[CR]'+loc_str(30379))
					if dp.iscanceled():
						xbmc.log(msg='PlayStation Store:  User cancelled the wizard mid process', level=xbmc.LOGDEBUG)
						wizard_settings['game_list'][game_list_id]['success'] = False
						wizard_settings['game_list'][game_list_id]['command'] = None
						wizard_settings['game_list'][game_list_id]['command_name'] = None
						break
					# current_bg_dialog.update(int(100*(ii+1)/(len(PlayStation Store_addon_wizard.directory.get('userdata').get('dat_files').get('header'))+.001)),loc_str(30377),loc_str(30379))
					if RP_DEFAULTS.get(game_list_id):
						if not any([y in addons_available for y in [x for x in RP_DEFAULTS.get(game_list_id) if x] if y]):
							xbmc.log(msg='PlayStation Store:  Wizard did not find a default addon available for %(value)s, attempting to install.'%{'value':game_list_id}, level=xbmc.LOGDEBUG)
							for aa in RP_DEFAULTS.get(game_list_id):
								xbmc.log(msg='PlayStation Store:  Start install for %(value)s'%{'value':aa}, level=xbmc.LOGDEBUG)
								xbmc.executebuiltin('InstallAddon(%(value)s)'%{'value':aa},True)
								xbmc.log(msg='PlayStation Store:  Complete install execution for %(value)s'%{'value':aa}, level=xbmc.LOGDEBUG)
						if any([y in addons_available for y in [x for x in RP_DEFAULTS.get(game_list_id) if x] if y]):
							current_command = next(iter([y for y in [x for x in RP_DEFAULTS.get(game_list_id) if x] if y in addons_available]),'none')
							if PlayStation Store_addon_wizard.game_lists.update_game_list_header(game_list_id,header_key='emu_launcher',header_value='retroplayer',confirm_update=False):
								xbmc.log(msg='PlayStation Store:  Wizard update launcher for game list %(value)s to Retroplayer'%{'value':game_list_id}, level=xbmc.LOGDEBUG)
								if PlayStation Store_addon_wizard.game_lists.update_game_list_header(game_list_id,header_key='emu_default_addon',header_value=current_command,confirm_update=False):
									xbmc.log(msg='PlayStation Store:  Wizard update default addon for game list %(value)s to %(ext_command)s'%{'value':game_list_id,'ext_command':current_command}, level=xbmc.LOGDEBUG)
									wizard_settings['game_list'][game_list_id]['success'] = True
									wizard_settings['game_list'][game_list_id]['command'] = current_command
									wizard_settings['game_list'][game_list_id]['command_name'] = xbmcaddon.Addon(id=current_command).getAddonInfo('name')
						else:
							xbmc.log(msg='PlayStation Store:  Wizard could not install a default addon for %(value)s'%{'value':game_list_id}, level=xbmc.LOGDEBUG)
					else:
						xbmc.log(msg='PlayStation Store:  Wizard did not find a default addon for %(value)s'%{'value':game_list_id}, level=xbmc.LOGERROR)
			dp.close()
			del dp
			# current_bg_dialog.close()
			# xbmc.executebuiltin('Dialog.Close(extendedprogressdialog,true)')
			# check_and_close_notification(notification_id='extendedprogressdialog')
			# del current_bg_dialog
		elif yesno_ret == 2:
			dp = xbmcgui.DialogProgress()
			dp.create(loc_str(30377),loc_str(30379))
			dp.update(0,loc_str(30379))
			# current_bg_dialog = xbmcgui.DialogProgressBG()
			# current_bg_dialog.create(loc_str(30377),loc_str(30379))
			for ii,hh in enumerate(PlayStation Store_addon_wizard.directory.get('userdata').get('dat_files').get('header')):
				if hh and hh.get('emu_visibility') and hh.get('emu_visibility') != 'hidden':
					current_fn = PlayStation Store_addon_wizard.directory.get('userdata').get('dat_files').get('files')[ii]
					game_list_id = current_fn.name.replace(current_fn.suffix,'')
					wizard_settings['game_list'][game_list_id] = dict()
					wizard_settings['game_list'][game_list_id]['success'] = False
					wizard_settings['game_list'][game_list_id]['command'] = None
					wizard_settings['game_list'][game_list_id]['command_name'] = None
					dp.update(int(100*(ii+1)/(len(PlayStation Store_addon_wizard.directory.get('userdata').get('dat_files').get('header'))+.001)),loc_str(30377)+'[CR]'+loc_str(30379))
					if dp.iscanceled():
						xbmc.log(msg='PlayStation Store:  User cancelled the wizard mid process', level=xbmc.LOGDEBUG)
						wizard_settings['game_list'][game_list_id]['success'] = False
						wizard_settings['game_list'][game_list_id]['command'] = None
						wizard_settings['game_list'][game_list_id]['command_name'] = None
						break
					# current_bg_dialog.update(int(100*(ii+1)/(len(PlayStation Store_addon_wizard.directory.get('userdata').get('dat_files').get('header'))+.001)),loc_str(30377),loc_str(30379))
					current_command = 'none'
					if PlayStation Store_addon_wizard.game_lists.update_game_list_header(game_list_id,header_key='emu_launcher',header_value='retroplayer',confirm_update=False):
						xbmc.log(msg='PlayStation Store:  Wizard update launcher for game list %(value)s to Retroplayer'%{'value':game_list_id}, level=xbmc.LOGDEBUG)
						if PlayStation Store_addon_wizard.game_lists.update_game_list_header(game_list_id,header_key='emu_default_addon',header_value=current_command,confirm_update=False):
							xbmc.log(msg='PlayStation Store:  Wizard update default addon for game list %(value)s to Auto'%{'value':game_list_id}, level=xbmc.LOGDEBUG)
							wizard_settings['game_list'][game_list_id]['success'] = True
							wizard_settings['game_list'][game_list_id]['command'] = current_command
							wizard_settings['game_list'][game_list_id]['command_name'] = loc_str(30338)
			dp.close()
			del dp
			# current_bg_dialog.close()
			# xbmc.executebuiltin('Dialog.Close(extendedprogressdialog,true)')
			# check_and_close_notification(notification_id='extendedprogressdialog')
			# del current_bg_dialog
	if wizard_settings.get('game_list') and wizard_settings.get('game_list').keys() and all([wizard_settings.get('game_list').get(kk).get('success') for kk in wizard_settings.get('game_list').keys()]):
		xbmc.playSFX(DONE_SOUND,False)
		ok_ret = current_dialog.ok(loc_str(30005),loc_str(30590)%{'launch_type':launch_type})
	elif wizard_settings.get('game_list') and wizard_settings.get('game_list').keys() and any([wizard_settings.get('game_list').get(kk).get('success') for kk in wizard_settings.get('game_list').keys()]):
		xbmc.playSFX(DONE_SOUND,False)
		ok_ret = current_dialog.ok(loc_str(30005),loc_str(30591)%{'launch_type':launch_type})
	else:
		xbmc.playSFX(DONE_SOUND2,False)
		ok_ret = current_dialog.ok(loc_str(30005),loc_str(30592)%{'launch_type':launch_type})

	#Clear list cache and directory cache given updates completed above
	PlayStation Store_addon_wizard.clear_list_cache_folder()
	clear_mem_cache('PlayStation Store_directory')

	if current_dialog.yesno(loc_str(30007),loc_str(30391)):
		dp = xbmcgui.DialogProgress()
		PlayStation Store_addon_wizard = PlayStation Store_addon() #Reload settings based on wizard entries
		dp.create(loc_str(30377),loc_str(30379))
		dp.update(0,loc_str(30379))
		total_files = len(PlayStation Store_addon_wizard.directory.get('userdata').get('dat_files').get('files'))
		continue_processing = True
		for ii,current_fn in enumerate(PlayStation Store_addon_wizard.directory.get('userdata').get('dat_files').get('files')):
			if continue_processing:
				game_list_id = current_fn.name.replace(current_fn.suffix,'')
				percent = int(100.0 * ii / (total_files + .001))
				current_game_list = PlayStation Store_addon_wizard.game_lists.get_game_list(game_list_id)
				dp.update(percent,loc_str(30392)%{'game_list':current_game_list.get('emu_name')})
				if dp.iscanceled():
					continue_processing = False
					xbmc.log(msg='PlayStation Store:  User cancelled pre-cache processing', level=xbmc.LOGDEBUG)
					break
				_ = PlayStation Store_addon_wizard.game_lists.get_games_from_cache(game_list_id=current_fn.name.replace(current_fn.suffix,''))
		dp.close()
		del dp

	if PlayStation Store_addon_wizard.handle.getSetting(id='PlayStation Store_wizard_launcher_report')=='0':
		xbmc.log(msg='PlayStation Store:  Generating Wizard Report', level=xbmc.LOGDEBUG)
		report_items = dict()
		report_items['label'] = list()
		report_items['art'] = list()
		report_items['info'] = list()
		report_items['label'].append('PlayStation Store Wizard Report ([COLOR green]UPDATED[/COLOR], [COLOR red]NOT UPDATED[/COLOR], [COLOR dimgray]HIDDEN[/COLOR])')
		report_items['art'].append(None)
		report_items['info'].append(None)
		if wizard_settings.get('wizard_launcher')=='0':
			report_items['label'].append('Settings updated for [B]Kodi Retroplayer[/B]')
			report_items['art'].append(None)
			report_items['info'].append(None)
			launch_type = 'Game Addon'
		else:
			report_items['label'].append('Settings updated for [B]External Launching[/B]')
			report_items['art'].append(None)
			report_items['info'].append(None)
			launch_type = 'External Launcher'
			
		PlayStation Store_addon_wizard = PlayStation Store_addon() #Reload settings based on wizard entries
		for ii,hh in enumerate(PlayStation Store_addon_wizard.directory.get('userdata').get('dat_files').get('header')):
			if hh:
				current_fn = PlayStation Store_addon_wizard.directory.get('userdata').get('dat_files').get('files')[ii]
				game_list_id = current_fn.name.replace(current_fn.suffix,'')
				current_launcher = 'Unknown'
				if wizard_settings.get('game_list') and wizard_settings.get('game_list').get(game_list_id) and wizard_settings.get('game_list').get(game_list_id).get('command_name'):
					current_launcher = wizard_settings.get('game_list').get(game_list_id).get('command_name')
				else:
					if PlayStation Store_addon_wizard.handle.getSetting(id='PlayStation Store_wizard_launcher_report')=='0':
						current_launcher = hh.get('emu_ext_launch_cmd')
					else:
						current_launcher = hh.get('emu_default_addon')
				current_color = 'red'
				current_status = 'NOT UPDATED'
				if hh.get('emu_visibility') and hh.get('emu_visibility') == 'hidden':
					current_color = 'dimgray'
					current_status = 'HIDDEN'
				elif wizard_settings.get('game_list') and wizard_settings.get('game_list').get(game_list_id) and wizard_settings.get('game_list').get(game_list_id).get('success'):
					current_color = 'green'
					current_status = 'UPDATED'
				elif wizard_settings.get('game_list') and wizard_settings.get('game_list').get(game_list_id) and wizard_settings.get('game_list').get(game_list_id).get('success')==False:
					current_color = 'red'
					current_status = 'NOT UPDATED'
				report_item = 'Game List: %(current_game_list)s, Status: [COLOR %(current_color)s]%(current_status)s[/COLOR], %(launch_type)s: %(current_launcher)s'%{'current_color':current_color,'current_status':current_status,'current_game_list':hh.get('emu_name'),'launch_type':launch_type,'current_launcher':current_launcher}
				report_items['label'].append(report_item)
				report_items['art'].append({'poster':choose_image(hh.get('emu_thumb')),'banner':choose_image(hh.get('emu_banner')),'fanart':choose_image(hh.get('emu_fanart')),'clearlogo':choose_image(hh.get('emu_logo')),'icon':choose_image(hh.get('emu_logo')),'thumb':choose_image(hh.get('emu_thumb'))})
				current_emu_postdlaction = get_post_dl_commands().get(hh.get('emu_postdlaction'))
				if not current_emu_postdlaction:
					current_emu_postdlaction = hh.get('emu_postdlaction')
				launch_command_string = ''
				download_path_string = loc_str(30361)
				current_header = loc_str(30362)%{'game_list_id':game_list_id}
				if hh.get('emu_launcher') == 'external':
					if hh.get('emu_ext_launch_cmd') == 'none':
						launch_command_string = '[COLOR FF12A0C7]%(elc)s:  [/COLOR]Not Set!'%{'elc':loc_str(30363)}
					else:
						launch_command_string = '[COLOR FF12A0C7]%(elc)s:  [/COLOR]%(lc)s'%{'elc':loc_str(30363),'lc':hh.get('emu_ext_launch_cmd')}
				if hh.get('emu_launcher') == 'retroplayer':
					if hh.get('emu_default_addon') == 'none':
						launch_command_string = '[COLOR FF12A0C7]%(rp)s:  [/COLOR]%(auto)s'%{'rp':loc_str(30364),'auto':loc_str(30338)}
					else:
						launch_command_string = '[COLOR FF12A0C7]%(rp)s:  [/COLOR]%(lc)s'%{'rp':loc_str(30364),'lc':hh.get('emu_default_addon')}
				if hh.get('emu_downloadpath') != 'default':
					download_path_string = hh.get('emu_downloadpath_resolved')
				current_text = '[B]%(md)s[/B][CR][COLOR FF12A0C7]%(gln)s:  [/COLOR]%(emu_name)s[CR][COLOR FF12A0C7]%(cat)s:  [/COLOR]%(emu_category)s[CR][COLOR FF12A0C7]%(platform_string)s:  [/COLOR]%(emu_description)s[CR][COLOR FF12A0C7]%(author_string)s:  [/COLOR]%(emu_author)s[CR][CR][B]%(dp)s[/B][CR][COLOR FF12A0C7]%(source)s:  [/COLOR]%(download_source)s[CR][COLOR FF12A0C7]%(dl)s:  [/COLOR]%(download_path_string)s[CR][COLOR FF12A0C7]%(pdlc)s:  [/COLOR]%(emu_postdlaction)s[CR][CR][B]%(lp)s[/B][CR][COLOR FF12A0C7]%(lw)s:  [/COLOR]%(emu_launcher)s[CR]%(launch_command_string)s'%{'emu_name':hh.get('emu_name'),'emu_category':hh.get('emu_category'),'emu_description':hh.get('emu_description'),'emu_author':hh.get('emu_author'),'download_source':hh.get('download_source'),'emu_postdlaction':current_emu_postdlaction,'emu_launcher':{'retroplayer':loc_str(30128),'external':loc_str(30003)}.get(hh.get('emu_launcher')),'launch_command_string':launch_command_string,'download_path_string':download_path_string,'platform_string':loc_str(30416),'author_string':loc_str(30419),'gln':loc_str(30365),'cat':loc_str(30415),'dp':loc_str(30366),'source':loc_str(30368),'dl':loc_str(30367),'pdlc':loc_str(30369),'lp':loc_str(30370),'lw':loc_str(30371),'md':loc_str(30372)}
				report_items['info'].append({'plot':current_text})
		set_mem_cache('PlayStation Store_wizard_results',report_items)
		xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.PlayStation Store/wizard_report")')
	else:
		xbmc.log(msg='PlayStation Store:  Wizard Report Skipped', level=xbmc.LOGDEBUG)		
	clear_mem_cache('PlayStation Store_script_started')
	xbmc.log(msg='PlayStation Store:  Wizard script completed', level=xbmc.LOGDEBUG)
else:
	xbmc.log(msg='PlayStation Store:  Script already running', level=xbmc.LOGDEBUG)
del PlayStation Store_addon_wizard, loc_str, get_mem_cache, set_mem_cache, clear_mem_cache, check_and_close_notification, choose_image, get_post_dl_commands