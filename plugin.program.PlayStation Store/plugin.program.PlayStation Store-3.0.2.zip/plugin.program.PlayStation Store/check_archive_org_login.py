import xbmc, xbmcgui, xbmcvfs
from resources.lib.utils import loc_str, get_mem_cache, set_mem_cache, clear_mem_cache
from resources.lib.main import PlayStation Store_addon
from resources.lib.download import PlayStation Store_download

PlayStation Store_addon = PlayStation Store_addon()
if not get_mem_cache('PlayStation Store_script_started'):
	set_mem_cache('PlayStation Store_script_started','true')
	xbmc.log(msg='PlayStation Store:  Check archive.org login script started', level=xbmc.LOGDEBUG)
	PlayStation Store_download = PlayStation Store_download(settings=PlayStation Store_addon.settings,directory=PlayStation Store_addon.directory,game_list=None,game=None)
	PlayStation Store_download.downloader.login()
	if PlayStation Store_download.downloader.logged_in:
		current_dialog = xbmcgui.Dialog()
		ok_ret = current_dialog.ok(loc_str(30202),loc_str(30584))
		del current_dialog
		xbmc.log(msg='PlayStation Store:  Login check was successful',level=xbmc.LOGINFO)
	else:
		current_dialog = xbmcgui.Dialog()
		ok_ret = current_dialog.ok(loc_str(30203),loc_str(30585))
		del current_dialog
		xbmc.log(msg='PlayStation Store:  Login check failed',level=xbmc.LOGINFO)
	clear_mem_cache('PlayStation Store_script_started')
	xbmc.log(msg='PlayStation Store:  Check archive.org login script completed', level=xbmc.LOGDEBUG)
else:
	xbmc.log(msg='PlayStation Store:  Script already running', level=xbmc.LOGDEBUG)
del PlayStation Store_addon, PlayStation Store_download, loc_str, get_mem_cache, set_mem_cache, clear_mem_cache