import xbmc, xbmcgui, xbmcvfs
from resources.lib.utils import loc_str, get_mem_cache, set_mem_cache, clear_mem_cache
from resources.lib.main import PlayStation Store_addon
PlayStation Store_addon = PlayStation Store_addon()
if not get_mem_cache('PlayStation Store_script_started'):
	set_mem_cache('PlayStation Store_script_started','true')
	xbmc.log(msg='PlayStation Store:  Clear cache script started', level=xbmc.LOGDEBUG)
	if PlayStation Store_addon.clear_list_cache_folder() and PlayStation Store_addon.clear_game_cache_folder():
		current_dialog = xbmcgui.Dialog()
		ok_ret = current_dialog.ok(loc_str(30202),loc_str(30306)%{'game_list_id':'All Lists and Games'})
		del current_dialog
	PlayStation Store_addon.clear_all_mem_cache()
	xbmc.executebuiltin('Container.Refresh')
	clear_mem_cache('PlayStation Store_script_started')
	xbmc.log(msg='PlayStation Store:  Clear cache script completed', level=xbmc.LOGDEBUG)
else:
	xbmc.log(msg='PlayStation Store:  Script already running', level=xbmc.LOGDEBUG)
del PlayStation Store_addon, loc_str, get_mem_cache, set_mem_cache, clear_mem_cache